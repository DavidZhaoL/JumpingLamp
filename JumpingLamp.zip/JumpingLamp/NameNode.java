import gmaths.*;
import com.jogamp.opengl.*;

public class NameNode extends SGNode {
  
  public NameNode(String name) {
    super(name);
  }
  
}